forceload add ~-16 ~-16 ~96 ~16
fill ~15 ~-5 ~-3 ~16 ~-2 ~3 minecraft:end_stone
fill ~15 ~-1 ~-2 ~16 ~-1 ~2 minecraft:smooth_quartz
fill ~17 ~0 ~-2 ~17 ~0 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
setblock ~17 ~0 ~-3 minecraft:sea_lantern
setblock ~17 ~1 ~-3 minecraft:end_rod
setblock ~17 ~0 ~3 minecraft:sea_lantern
setblock ~17 ~1 ~3 minecraft:end_rod
fill ~18 ~1 ~-2 ~18 ~1 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~18 ~0 ~-2 ~18 ~0 ~2 minecraft:purpur_block
fill ~19 ~2 ~-2 ~19 ~2 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~19 ~1 ~-2 ~19 ~1 ~2 minecraft:purpur_block
fill ~20 ~3 ~-2 ~20 ~3 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~20 ~2 ~-2 ~20 ~2 ~2 minecraft:purpur_block
fill ~21 ~4 ~-2 ~21 ~4 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~21 ~3 ~-2 ~21 ~3 ~2 minecraft:purpur_block
setblock ~21 ~4 ~-3 minecraft:sea_lantern
setblock ~21 ~5 ~-3 minecraft:end_rod
setblock ~21 ~4 ~3 minecraft:sea_lantern
setblock ~21 ~5 ~3 minecraft:end_rod
fill ~22 ~5 ~-2 ~22 ~5 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~22 ~4 ~-2 ~22 ~4 ~2 minecraft:purpur_block
fill ~23 ~6 ~-2 ~23 ~6 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~23 ~5 ~-2 ~23 ~5 ~2 minecraft:purpur_block
fill ~24 ~7 ~-2 ~24 ~7 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~24 ~6 ~-2 ~24 ~6 ~2 minecraft:purpur_block
fill ~25 ~8 ~-2 ~25 ~8 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~25 ~7 ~-2 ~25 ~7 ~2 minecraft:purpur_block
setblock ~25 ~8 ~-3 minecraft:sea_lantern
setblock ~25 ~9 ~-3 minecraft:end_rod
setblock ~25 ~8 ~3 minecraft:sea_lantern
setblock ~25 ~9 ~3 minecraft:end_rod
fill ~26 ~9 ~-2 ~26 ~9 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~26 ~8 ~-2 ~26 ~8 ~2 minecraft:purpur_block
fill ~27 ~10 ~-2 ~27 ~10 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~27 ~9 ~-2 ~27 ~9 ~2 minecraft:purpur_block
fill ~28 ~11 ~-2 ~28 ~11 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~28 ~10 ~-2 ~28 ~10 ~2 minecraft:purpur_block
fill ~29 ~12 ~-2 ~29 ~12 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~29 ~11 ~-2 ~29 ~11 ~2 minecraft:purpur_block
setblock ~29 ~12 ~-3 minecraft:sea_lantern
setblock ~29 ~13 ~-3 minecraft:end_rod
setblock ~29 ~12 ~3 minecraft:sea_lantern
setblock ~29 ~13 ~3 minecraft:end_rod
fill ~30 ~13 ~-2 ~30 ~13 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~30 ~12 ~-2 ~30 ~12 ~2 minecraft:purpur_block
fill ~31 ~14 ~-2 ~31 ~14 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~31 ~13 ~-2 ~31 ~13 ~2 minecraft:purpur_block
fill ~32 ~15 ~-2 ~32 ~15 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~32 ~14 ~-2 ~32 ~14 ~2 minecraft:purpur_block
fill ~33 ~16 ~-2 ~33 ~16 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~33 ~15 ~-2 ~33 ~15 ~2 minecraft:purpur_block
setblock ~33 ~16 ~-3 minecraft:sea_lantern
setblock ~33 ~17 ~-3 minecraft:end_rod
setblock ~33 ~16 ~3 minecraft:sea_lantern
setblock ~33 ~17 ~3 minecraft:end_rod
fill ~34 ~17 ~-2 ~34 ~17 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~34 ~16 ~-2 ~34 ~16 ~2 minecraft:purpur_block
fill ~35 ~18 ~-2 ~35 ~18 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~35 ~17 ~-2 ~35 ~17 ~2 minecraft:purpur_block
fill ~36 ~19 ~-2 ~36 ~19 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~36 ~18 ~-2 ~36 ~18 ~2 minecraft:purpur_block
fill ~37 ~20 ~-2 ~37 ~20 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~37 ~19 ~-2 ~37 ~19 ~2 minecraft:purpur_block
setblock ~37 ~20 ~-3 minecraft:sea_lantern
setblock ~37 ~21 ~-3 minecraft:end_rod
setblock ~37 ~20 ~3 minecraft:sea_lantern
setblock ~37 ~21 ~3 minecraft:end_rod
fill ~38 ~21 ~-2 ~38 ~21 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~38 ~20 ~-2 ~38 ~20 ~2 minecraft:purpur_block
fill ~39 ~22 ~-2 ~39 ~22 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~39 ~21 ~-2 ~39 ~21 ~2 minecraft:purpur_block
fill ~40 ~23 ~-2 ~40 ~23 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~40 ~22 ~-2 ~40 ~22 ~2 minecraft:purpur_block
fill ~41 ~24 ~-2 ~41 ~24 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~41 ~23 ~-2 ~41 ~23 ~2 minecraft:purpur_block
setblock ~41 ~24 ~-3 minecraft:sea_lantern
setblock ~41 ~25 ~-3 minecraft:end_rod
setblock ~41 ~24 ~3 minecraft:sea_lantern
setblock ~41 ~25 ~3 minecraft:end_rod
fill ~42 ~25 ~-2 ~42 ~25 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~42 ~24 ~-2 ~42 ~24 ~2 minecraft:purpur_block
fill ~43 ~26 ~-2 ~43 ~26 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~43 ~25 ~-2 ~43 ~25 ~2 minecraft:purpur_block
fill ~44 ~27 ~-2 ~44 ~27 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~44 ~26 ~-2 ~44 ~26 ~2 minecraft:purpur_block
fill ~45 ~28 ~-2 ~45 ~28 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~45 ~27 ~-2 ~45 ~27 ~2 minecraft:purpur_block
setblock ~45 ~28 ~-3 minecraft:sea_lantern
setblock ~45 ~29 ~-3 minecraft:end_rod
setblock ~45 ~28 ~3 minecraft:sea_lantern
setblock ~45 ~29 ~3 minecraft:end_rod
fill ~46 ~29 ~-2 ~46 ~29 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~46 ~28 ~-2 ~46 ~28 ~2 minecraft:purpur_block
fill ~47 ~30 ~-2 ~47 ~30 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~47 ~29 ~-2 ~47 ~29 ~2 minecraft:purpur_block
fill ~48 ~31 ~-2 ~48 ~31 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~48 ~30 ~-2 ~48 ~30 ~2 minecraft:purpur_block
fill ~49 ~32 ~-2 ~49 ~32 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~49 ~31 ~-2 ~49 ~31 ~2 minecraft:purpur_block
setblock ~49 ~32 ~-3 minecraft:sea_lantern
setblock ~49 ~33 ~-3 minecraft:end_rod
setblock ~49 ~32 ~3 minecraft:sea_lantern
setblock ~49 ~33 ~3 minecraft:end_rod
fill ~50 ~33 ~-2 ~50 ~33 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~50 ~32 ~-2 ~50 ~32 ~2 minecraft:purpur_block
fill ~51 ~34 ~-2 ~51 ~34 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~51 ~33 ~-2 ~51 ~33 ~2 minecraft:purpur_block
fill ~52 ~35 ~-2 ~52 ~35 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~52 ~34 ~-2 ~52 ~34 ~2 minecraft:purpur_block
fill ~53 ~36 ~-2 ~53 ~36 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~53 ~35 ~-2 ~53 ~35 ~2 minecraft:purpur_block
setblock ~53 ~36 ~-3 minecraft:sea_lantern
setblock ~53 ~37 ~-3 minecraft:end_rod
setblock ~53 ~36 ~3 minecraft:sea_lantern
setblock ~53 ~37 ~3 minecraft:end_rod
fill ~54 ~37 ~-2 ~54 ~37 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~54 ~36 ~-2 ~54 ~36 ~2 minecraft:purpur_block
fill ~55 ~38 ~-2 ~55 ~38 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~55 ~37 ~-2 ~55 ~37 ~2 minecraft:purpur_block
fill ~56 ~39 ~-2 ~56 ~39 ~2 minecraft:purpur_stairs[facing=east,half=bottom]
fill ~56 ~38 ~-2 ~56 ~38 ~2 minecraft:purpur_block
fill ~25 ~-1 ~-3 ~25 ~7 ~-3 minecraft:purpur_pillar
fill ~25 ~-1 ~3 ~25 ~7 ~3 minecraft:purpur_pillar
fill ~33 ~-1 ~-3 ~33 ~15 ~-3 minecraft:purpur_pillar
fill ~33 ~-1 ~3 ~33 ~15 ~3 minecraft:purpur_pillar
fill ~41 ~-1 ~-3 ~41 ~23 ~-3 minecraft:purpur_pillar
fill ~41 ~-1 ~3 ~41 ~23 ~3 minecraft:purpur_pillar
fill ~49 ~-1 ~-3 ~49 ~31 ~-3 minecraft:purpur_pillar
fill ~49 ~-1 ~3 ~49 ~31 ~3 minecraft:purpur_pillar
fill ~57 ~39 ~-4 ~87 ~39 ~4 minecraft:smooth_quartz
fill ~58 ~39 ~-3 ~86 ~39 ~3 minecraft:purpur_block
fill ~71 ~39 ~-1 ~73 ~39 ~1 minecraft:sea_lantern
setblock ~57 ~40 ~-4 minecraft:end_rod
setblock ~57 ~40 ~4 minecraft:end_rod
setblock ~87 ~40 ~-4 minecraft:end_rod
setblock ~87 ~40 ~4 minecraft:end_rod
execute unless entity @e[type=minecraft:marker,tag=galaxy_pship,distance=..150] run summon minecraft:marker ~72 ~40 ~0 {Tags:["galaxy_pship"]}
tellraw @a {"text":"A stairway of starlight rises to the ship that will take you home.","color":"light_purple"}
