fill -1 200 -1 1 200 1 minecraft:air
playsound minecraft:block.piston.extend ambient @s ~ ~ ~ 2 0.7
playsound minecraft:block.iron_door.open ambient @s ~ ~ ~ 2 0.6
title @s actionbar {"text":"Floor hatch opening... get ready to jump!","color":"yellow"}
particle minecraft:cloud 0.5 200.5 0.5 1 0.2 1 0.2 40 force @s
