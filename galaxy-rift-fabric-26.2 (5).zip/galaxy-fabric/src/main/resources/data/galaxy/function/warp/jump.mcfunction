effect clear @s minecraft:speed
effect clear @s minecraft:resistance
effect give @s minecraft:slow_falling 60 0 true
effect give @s minecraft:resistance 20 4 true
tp @s 0.00 207.00 -23.00 facing 0 203 2
scoreboard players set @s galaxy_c 1
playsound minecraft:item.elytra.flying player @s ~ ~ ~ 1 1
playsound minecraft:entity.ender_dragon.flap player @s ~ ~ ~ 2 0.8
