execute in galaxy:starfall as @e[type=minecraft:marker,tag=galaxy_citadel,limit=1] at @s run function galaxy:citadel/stairs_build
