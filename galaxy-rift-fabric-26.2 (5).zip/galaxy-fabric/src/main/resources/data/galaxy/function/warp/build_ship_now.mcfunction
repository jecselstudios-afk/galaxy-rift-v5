fill -13 199 -11 13 212 16 minecraft:air
fill -4 200 -6 4 205 6 galaxy:ship_hull
fill -3 201 -5 3 204 5 minecraft:air
fill -3 200 7 3 205 7 galaxy:ship_hull
fill -3 200 8 3 204 8 galaxy:ship_hull
fill -2 200 9 2 204 9 galaxy:ship_hull
fill -2 200 10 2 203 10 galaxy:ship_hull
fill -1 200 11 1 203 11 galaxy:ship_hull
fill -1 200 12 1 202 12 galaxy:ship_hull
fill 0 200 13 0 201 13 galaxy:ship_hull
fill -2 201 6 2 203 8 minecraft:air
fill -1 202 9 1 203 9 minecraft:barrier
fill 3 202 7 3 203 8 minecraft:barrier
fill -3 202 7 -3 203 8 minecraft:barrier
fill 4 202 -3 4 203 3 minecraft:barrier
fill -4 202 -3 -4 203 3 minecraft:barrier
fill -2 201 8 2 201 8 galaxy:ship_dark
fill -1 202 8 1 202 8 galaxy:ship_glow
fill -4 205 -6 4 205 6 galaxy:ship_dark
fill -4 200 -6 -4 200 6 galaxy:ship_dark
fill 4 200 -6 4 200 6 galaxy:ship_dark
fill -4 201 -5 -4 201 5 galaxy:ship_glow
fill 4 201 -5 4 201 5 galaxy:ship_glow
fill -2 200 -5 -2 200 5 galaxy:ship_glow
fill 2 200 -5 2 200 5 galaxy:ship_glow
fill -3 200 -9 3 204 -7 galaxy:ship_dark
fill 1 201 -10 3 203 -10 galaxy:ship_engine
fill -3 201 -10 -1 203 -10 galaxy:ship_engine
fill 5 201 -6 5 201 1 galaxy:ship_dark
fill -5 201 -6 -5 201 1 galaxy:ship_dark
fill 6 201 -7 6 201 0 galaxy:ship_dark
fill -6 201 -7 -6 201 0 galaxy:ship_dark
fill 7 201 -8 7 201 0 galaxy:ship_dark
fill -7 201 -8 -7 201 0 galaxy:ship_dark
fill 8 201 -8 8 201 -1 galaxy:ship_dark
fill -8 201 -8 -8 201 -1 galaxy:ship_dark
fill 9 201 -8 9 201 -2 galaxy:ship_dark
fill -9 201 -8 -9 201 -2 galaxy:ship_dark
fill 10 201 -9 10 201 -2 galaxy:ship_dark
fill -10 201 -9 -10 201 -2 galaxy:ship_dark
fill 11 201 -10 11 201 -3 galaxy:ship_dark
fill -11 201 -10 -11 201 -3 galaxy:ship_dark
fill 12 201 -10 12 201 -4 galaxy:ship_dark
fill -12 201 -10 -12 201 -4 galaxy:ship_dark
fill 5 202 -6 5 202 0 galaxy:ship_dark
fill -5 202 -6 -5 202 0 galaxy:ship_dark
setblock 12 201 -10 galaxy:ship_glow
setblock -12 201 -10 galaxy:ship_glow
setblock 12 201 -9 galaxy:ship_glow
setblock -12 201 -9 galaxy:ship_glow
fill 0 205 -9 0 205 -6 galaxy:ship_dark
fill 0 206 -8 0 206 -6 galaxy:ship_dark
fill 0 207 -7 0 207 -6 galaxy:ship_dark
fill 0 208 -6 0 209 -6 galaxy:ship_dark
setblock 0 209 -6 galaxy:ship_glow
fill -1 200 -1 1 200 1 galaxy:ship_hull
